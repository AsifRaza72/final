import LoginForm from "./Components/LoginForm";
import Dashboard from "./Components/Dashboard";
function App() {
  return (
    <div className="App">
    <LoginForm/>
    <Dashboard/>
    </div>
  );
}

export default App;
