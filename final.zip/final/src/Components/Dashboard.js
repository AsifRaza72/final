import  React from'react'
import ProductList from './ProductList';
const Dashboard=()=>{
    return(
        <div key={ProductList.id}>
            <p>{ProductList.Title}</p>
        </div>
    )
}
export default Dashboard;