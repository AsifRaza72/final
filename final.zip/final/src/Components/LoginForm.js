import React,{useState} from 'react'
import './LoginForm.css'
const LoginForm=()=>{
    const [isName,setIsName]=useState('')
    const [isPassword,setIsPassword]=useState('')
    const [isFormValid,setisFormValid]=useState('')

    const NameHandler=(event)=>{
        if(event.target.value.length().trim() >3){
            setIsName(true)
        }
    
    }
    const PasswordHandler=(event)=>{
        if(event.target.value.length().trim() >6)
        {
            setIsPassword(true)
        }
    }
        
      const SubmitHandler=()=>{
        if(isName && isPassword){
        setisFormValid(true)
        }
       
      }
    
    return(
     <div className='body'>
        <div> 
        <label  >UserName :</label>
        <input type='text'value={isName} onChange={NameHandler}/>
        </div> 
        <div>
        <label for='password'>Password :</label>
        <input id='password' value={isPassword} onChange={PasswordHandler}/>
        </div> 
        <div style={{justifyContent:'center'}}>
             <button type='submit' onSubmit={SubmitHandler} value={isFormValid}>Login</button>
             </div>
       
        
       
     </div>
    )
}
export default LoginForm;